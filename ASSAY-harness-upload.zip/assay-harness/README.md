# ASSAY — Judging Harness (v0)

Robot penilai otomatis untuk kompetisi build-game pakai AI (BYOT). Repo publik, jalan gratis di GitHub Actions.

## Status: Phase 1 (MVP Gate A) ✅
Pipeline: `arena.json` (zod) → build dari clean → serve → smoke (load<5s, 0 console-error) → spec **+ seed** (Playwright) → score (`config/weights.json`) → report + Discord. Flag `SEED_MISMATCH` = indikator prebuilt.

## Jalan lokal
```
npm install
npx playwright install chromium         # butuh system libs (CI: --with-deps)
npm run judge -- --submission <dir> --participant p1 --brief 01-endless-runner --seed '{"theme":"teko terbang"}' --track casual
```
Bukti Gate A (tanpa browser, pakai jsdom): `npx tsx tests/logic-selftest.ts` → good 100 > prebuilt 89 (SEED_MISMATCH) > bad 48 (SMOKE_FAIL).

## Roadmap
- Phase 2: Lighthouse (perf) + axe (a11y) + screenshots + forensik (commit cadence, jscpd similarity, prompt-injection scan) + precheck load-test.
- Phase 3 (pre-W6): LLM panel (3 model pinned, config/models.json) + anchors + Glicko-2 + golden-set drift cron.

## Nambah brief
`briefs/<id>.ts` export `Brief` (lihat `01-endless-runner.ts`) + `briefs/seeds/<id>.json`.
