# PANDUAN DEPLOY ASSAY — buat Ben (no coding)

Tujuan: naikin harness ke GitHub biar bisa jalan otomatis. ~15 menit. Gua bisa temenin lewat browser pas lo siap.

## Yang lo pegang
Folder `assay-harness` (ada di bundle `assay-harness.zip`). Lo gak usah ngerti isinya. Lo cuma upload + set 2 kunci.

## Langkah
1. **Akun GitHub** — buka github.com, daftar (gratis). Skip kalau udah punya.
2. **Bikin repo** — pojok kanan atas `+` → *New repository* → nama: `assay-harness` → pilih **Public** → *Create repository*.
3. **Upload** — di halaman repo baru, klik *uploading an existing file* → drag SEMUA isi folder `assay-harness` (setelah unzip). **JANGAN** ikutkan folder `node_modules` kalau ada (gak perlu) → *Commit changes*.
4. **Aktifkan Actions** — buka tab **Actions**, kalau ada tombol hijau "I understand..." klik biar aktif.
5. **Set 2 kunci** (boleh dikosongin dulu buat tes pertama) — Settings → *Secrets and variables* → *Actions* → *New repository secret*:
   - `DISCORD_WEBHOOK` → isi pas server Discord udah jadi (buat kirim hasil ke channel).
   - `LLM_API_KEY` → isi pas Phase 3 / W6 (panel LLM). Belum perlu sekarang.
6. **Tes jalan** — tab **Actions** → pilih *ASSAY Judge* → *Run workflow* → isi:
   - `submission` = URL repo game contoh (public)
   - `participant` = nama
   - `seed` = biarin default
   → *Run*. Hasil skor keluar di *Artifacts* (+ Discord kalau webhook diisi).

## Catatan
- Repo ini PUBLIC on purpose = kredibilitas (Blueprint §8.5: orang percaya sistem yg bisa diaudit).
- Kalau ke-stuck di step manapun, bilang gua — gua pandu klik-per-klik / lewat browser.
