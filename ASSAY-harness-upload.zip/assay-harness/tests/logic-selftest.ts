// LOCAL Gate-A proof: exercises REAL manifest+build+scoring+flags; swaps browser→jsdom for DOM checks.
// Production path = src/cli.ts (Playwright+Chromium on GitHub Actions).
import { JSDOM, VirtualConsole } from "jsdom";
import { readFileSync } from "node:fs";
import { join, resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { sh } from "../src/util.js";
import { readManifest } from "../src/gates/manifest.js";
import { buildSubmission } from "../src/gates/build.js";
import { aggregate } from "../src/score/aggregate.js";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const weights = JSON.parse(readFileSync(join(ROOT, "config/weights.json"), "utf8"));
const seed = { theme: "teko terbang" };

function judge(name: string) {
  const work = `/tmp/assay-logic/${name}`;
  sh(`rm -rf "${work}" && mkdir -p "${work}" && cp -r "${join(ROOT, "fixtures", name)}/." "${work}/"`, ROOT);
  const man = readManifest(work);
  if (!man.ok) return { name, score: 0, flags: ["MANIFEST_FAIL:" + man.error], checks: [] as any[] };
  const b = buildSubmission(work, man.manifest!);
  if (!b.ok) { const a = aggregate({ build: 0 }, weights.harness_components, "casual", weights.tracks); return { name, score: a.score, flags: ["BUILD_FAIL"], checks: [] as any[] }; }

  const html = readFileSync(join(b.distPath, "index.html"), "utf8");
  const vc = new VirtualConsole(); const errs: string[] = [];
  const ignore = (s: string) => /getcontext|not implemented/i.test(s); // jsdom has no canvas; real Chromium does
  vc.on("error", (m) => { const s = String(m); if (!ignore(s)) errs.push(s); });
  vc.on("jsdomError", (e) => { if (!ignore(e.message)) errs.push(e.message); });
  const dom = new JSDOM(html, { runScripts: "dangerously", virtualConsole: vc });
  const w = dom.window as any, d = w.document;

  const checks = [
    { id: "canvas", seed: false, pass: !!d.querySelector("canvas#game") },
    { id: "score", seed: false, pass: /\d/.test(d.querySelector("#score")?.textContent || "") },
    { id: "hook", seed: false, pass: typeof w.__assay?.start === "function" },
    { id: "gameover", seed: false, pass: (() => { try { w.__assay?.simulateCollision?.(); const el = d.querySelector("#gameover"); return !!el && !el.hasAttribute("hidden"); } catch { return false; } })() },
    { id: "seed", seed: true, pass: (d.body.textContent + " " + d.body.outerHTML).toLowerCase().includes(seed.theme) },
  ];
  const smokeOk = errs.length === 0;
  const specPass = checks.filter(c => c.pass).length / checks.length;
  const a = aggregate({ build: 1, smoke: smokeOk ? 1 : 0, spec_seed: specPass }, weights.harness_components, "casual", weights.tracks);
  const flags: string[] = []; if (!smokeOk) flags.push("SMOKE_FAIL");
  const ns = checks.filter(c => !c.seed), sd = checks.filter(c => c.seed);
  if (sd.length && sd.every(c => !c.pass) && ns.length && ns.every(c => c.pass)) flags.push("SEED_MISMATCH(prebuilt?)");
  return { name, score: a.score, flags, checks };
}

const rows = ["good", "bad", "prebuilt"].map(judge);
console.log("\n=== GATE A SELF-TEST (logic) ===");
for (const r of rows) console.log(`${r.name.padEnd(9)} score=${String(r.score).padStart(3)}/100  checks=${r.checks.filter((c:any)=>c.pass).length}/${r.checks.length||"-"}  flags=[${r.flags.join(", ")}]`);
const [g, b, p] = rows;
const A: [string, boolean][] = [
  ["good > bad", g.score > b.score],
  ["good > prebuilt", g.score > p.score],
  ["good TANPA SEED_MISMATCH", !g.flags.some(f => f.includes("SEED_MISMATCH"))],
  ["prebuilt ke-flag SEED_MISMATCH", p.flags.some(f => f.includes("SEED_MISMATCH"))],
  ["bad ke-flag SMOKE_FAIL", b.flags.some(f => f.includes("SMOKE_FAIL"))],
];
let ok = true; console.log("\n=== ASSERTIONS ===");
for (const [l, pass] of A) { console.log(`${pass ? "✓" : "✗"} ${l}`); if (!pass) ok = false; }
console.log(ok ? "\nGATE A (logic): PASS ✅" : "\nGATE A (logic): FAIL ❌");
process.exit(ok ? 0 : 1);
