import { judgeSubmission } from "../src/cli.js";
import { resolve, dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const seed = { theme: "teko terbang" };
const out = "/tmp/assay-out";

const run = (name: string) => judgeSubmission({
  submissionDir: join(ROOT, "fixtures", name), participant: name, briefId: "01-endless-runner",
  seed, division: "open", track: "casual", outDir: out,
});

const rows = [await run("good"), await run("bad"), await run("prebuilt")];
console.log("\n=== GATE A SELF-TEST ===");
for (const r of rows) console.log(`${r.participant.padEnd(9)} score=${String(r.score).padStart(3)}  build=${r.build_ok?"ok":"X"} smoke=${r.smoke_ok?"ok":"X"}  flags=[${r.flags.join(",")}]`);

const g = rows[0], b = rows[1], p = rows[2];
const checks = [
  ["good > bad", g.score > b.score],
  ["good > prebuilt", g.score > p.score],
  ["good tanpa SEED_MISMATCH", !g.flags.some(f=>f.includes("SEED_MISMATCH"))],
  ["prebuilt ke-flag SEED_MISMATCH", p.flags.some(f=>f.includes("SEED_MISMATCH"))],
  ["bad ke-flag SMOKE_FAIL", b.flags.some(f=>f.includes("SMOKE_FAIL"))],
];
let ok = true;
console.log("\n=== ASSERTIONS ===");
for (const [label, pass] of checks) { console.log(`${pass?"✓":"✗"} ${label}`); if(!pass) ok=false; }
console.log(ok ? "\nGATE A: PASS ✅" : "\nGATE A: FAIL ❌");
process.exit(ok ? 0 : 1);
